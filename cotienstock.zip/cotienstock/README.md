# 🌸 Cô Tiên Stock — Hướng dẫn Deploy

## Kiến trúc
```
Frontend (index.html) → Vercel [FREE]
Backend (main.py)     → Railway.app [FREE — 500 giờ/tháng]
Data                  → vnstock API (VCI source)
```

---

## BƯỚC 1: Deploy Backend lên Railway.app

### 1.1 Tạo tài khoản Railway
- Vào https://railway.app → Sign up bằng GitHub (miễn phí)

### 1.2 Upload backend
1. Tạo folder `cotienstock-backend/` chứa:
   - `main.py`
   - `requirements.txt`
   - `railway.json`
2. Push lên GitHub repo mới (VD: `cotienstock-backend`)
3. Vào Railway → **New Project** → **Deploy from GitHub**
4. Chọn repo `cotienstock-backend` → Deploy

### 1.3 Lấy URL backend
- Sau khi deploy thành công, vào **Settings** → **Networking** → **Generate Domain**
- Copy URL dạng: `https://cotienstock-backend.up.railway.app`

---

## BƯỚC 2: Cập nhật API URL trong Frontend

Mở `index.html`, tìm dòng trong function `loadData`:

```javascript
// Thay YOUR_RAILWAY_URL bằng URL thực từ bước 1.3
const API_BASE = 'https://cotienstock-backend.up.railway.app';
```

Thêm đoạn fetch thực sau dòng `setTimeout`:

```javascript
// Fetch từ Railway backend
fetch(`${API_BASE}/api/stock/${ticker}`)
  .then(r => r.json())
  .then(data => {
    clearInterval(interval);
    document.getElementById('loadingState').style.display = 'none';
    renderAll(data);
  })
  .catch(err => {
    // Fallback về mock data nếu API lỗi
    console.warn('API error, dùng mock:', err);
    const data = MOCK[ticker] || generateMock(ticker);
    clearInterval(interval);
    document.getElementById('loadingState').style.display = 'none';
    renderAll(data);
  });
```

---

## BƯỚC 3: Deploy Frontend lên Vercel

### 3.1 Cách 1 — Vercel CLI (nhanh nhất)
```bash
npm i -g vercel
cd cotienstock/frontend
vercel --prod
```

### 3.2 Cách 2 — Vercel Web UI
1. Vào https://vercel.com → New Project
2. Import từ GitHub hoặc **drag & drop** thư mục `frontend/`
3. Framework: **Other** (Static HTML)
4. Deploy → nhận URL dạng `https://cotienstock.vercel.app`

---

## BƯỚC 4: Test

```bash
# Test backend local
pip install -r requirements.txt
uvicorn main:app --reload
# → http://localhost:8000
# → http://localhost:8000/api/stock/HPG

# Test frontend local (không cần Node.js)
# Mở index.html thẳng bằng trình duyệt
```

---

## Chi phí
| Service | Free Tier | Giới hạn |
|---------|-----------|----------|
| Vercel | ✅ Miễn phí | 100GB bandwidth/tháng |
| Railway | ✅ Miễn phí | 500 giờ CPU/tháng |
| vnstock | ✅ Miễn phí | Community: 8 kỳ, Sponsor: 40+ kỳ |

---

## Nâng cấp dữ liệu (tùy chọn)
- **Thêm CafeF fallback**: bổ sung `cafef_fallback.py` để lấy data cũ hơn 2022
- **Cache Redis**: thêm Railway Redis plugin ($0/tháng trong free tier)
- **Cron job**: dùng Railway Cron để pre-fetch top 100 mã mỗi đêm
- **Vercel KV**: lưu cache phía frontend (free 30MB)

---

## Cấu trúc file
```
cotienstock/
├── frontend/
│   ├── index.html        ← Toàn bộ UI (9 tab)
│   └── vercel.json       ← Vercel config
└── backend/
    ├── main.py           ← FastAPI endpoints
    ├── requirements.txt  ← Dependencies
    └── railway.json      ← Railway config
```
